Com base nos conceitos iniciais de banco de dados apresentados em sala, 
crie um código python que atenda aos seguintes requisitos:

1. Implemente uma tabela Aluno com os atributos id, nome e idade;
2. Implemente a operação de inserção de dados e popule a tabela com 10 registros; e
3. Implemente a recuperação de informação por meio do id do aluno.

Envie o código executável Python em zip para esse exercícios. Adicione um arquivo README.md com a descrição do projeto.

